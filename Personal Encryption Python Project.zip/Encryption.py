import random
valid = False
while valid == False:
    print("---------------------------------------------")
    print("Welcome to the Encryption Software!")
    print("---------------------------------------------")
    print("1. Encrypt")
    print("2. Decrypt")
    print("3. Exit")
    print("---------------------------------------------")
    choice = int(input("Enter your option: "))
    print("---------------------------------------------")
    while choice not in range (1,4):
        print("<error>")
        print("Invalid choice...")
        print("<error>")
        choice = int(input("Re-enter your option: "))
        print("---------------------------------------------")
    if choice == 1:
        encrypt = input("Enter your message: ")
        print("---------------------------------------------")
        array_en = list(encrypt)
        y = random.randint(33,767) #Used for encryption key
        d = random.randint(688,767) #Unicode fourth block
        array_de = []
        for i in range(0,len(array_en)): #Encodes 
            x = ord(array_en[i])
            x = x + y
            if x > 767:
                x = x - 736
            if x > 669 and x < 688:
                x = x + 18
            if x > 591 and x < 647:   
                x = x + 55
            if x > 126 and x < 161:
                x = x + 34
            x = chr(x)
            array_de.append(x)
        array_de = "".join(array_de)
        print("The encrypted message is: ")
        print(array_de)
        print("---------------------------------------------")
        t = y
        key = []
        while y != 0:
            a = random.randint(33,126) #Unicode first block
            y = y - a
            key.append(a)
            if y < 0:
                y = t
                key = []
        key_str = []
        for i in range(0,len(key)):
            v = chr(key[i])
            key_str.append(v)
        key_str = "".join(key_str)
        print("This is the key for decryption: ")
        print(key_str)
        print("---------------------------------------------")
    if choice == 2:
        decrypt = input("Enter your message: ")
        print("---------------------------------------------")
        key_de = input("Enter your key: ")
        print("---------------------------------------------")
        key_list = list(key_de)
        s = 0
        for i in range(0,len(key_list)):#Finds the key
            v = ord(key_list[i])
            s = s + v
        array = list(decrypt)
        listing = []
        for i in range(0,len(array)):#Decrypting 
            q = ord(array[i])
            q = q - s
            if q < 32:
                q = q + 736
            if q > 669 and x < 688:
                q = q - 18
            if q > 591 and q < 647:
                q = q - 55
            if q > 126 and q < 161:
                q = q - 34
            q = chr(q)
            listing.append(q)
        listing = "".join(listing)
        print("The decrypted message is: ")
        print(listing)
        print("---------------------------------------------")
    if choice ==3:
        valid = True
