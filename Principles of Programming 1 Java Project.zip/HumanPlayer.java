import java.util.Random;
import java.util.Scanner;

//This is the class that contains the accessors expressed in the player interface
//and it contains the data and methods for a human player
public class HumanPlayer implements Player{

  //This is the location of the player on the map
  protected int[] location;

  //This is the amount of gold that the player collected
  protected int goldCollected;

  //This is the symbol/icon that represents the player on the map
  protected char icon;

  //This shows whether the player is standing on gold or not
  protected boolean onGold;

  //This shows whether the player is standing on an exit or not
  protected boolean onExit;

  
  //This is the default constructor
  //@params : the map that is used in the game
  public HumanPlayer(Map map){
    goldCollected = 0;
    icon = 'P';
    onGold = false;
    onExit = false;
    location = locationselector(map);
  }

  
  //This is the constructor that is used by the bot (child class)
  //@params : the map that is used in the game and the icon of the player
  public HumanPlayer(Map map, char image){
    goldCollected = 0;
    icon = image;
    onGold = false;
    onExit = false;
    location = locationselector(map);
  }

  
  //Selects a random location for the player to start at
  //@params : the map of the game
  //@returns : location of the players as an integer array
  public int[] locationselector(Map map){
    Random random = new Random();
    boolean valid = false;
    int[] temploc;
    temploc = new int[2];
    char[][] array = map.getMap();
    int[] length = map.getLength();
    
    while (valid == false){
      //Generates a random x and y location on the map
      int x = random.nextInt(length[1]);
      int y = random.nextInt(length[0]);

      ///If the map has a '.' or 'E', then the player can be there
      //Otherwise, it repeats this loop
      if (array[y][x] == '.' || array[y][x] == 'E'){
        valid = true;
        temploc[0] = y;
        temploc[1] = x;

        //If the map has a 'E' in that location, onExit is set to true
        if (array[y][x] == 'E'){
          onExit = true;
        }
        
        //Changes the current location to the player's icon
        map.changeMap(temploc, icon);
      }
    }
    return temploc;
  }

  
  //This is the turn of the human player
  //@returns : the action of the player as an integer array
  public int[] Turn(){
    Scanner input = Main.inputter;
    int[] choice = new int[] {0,0};
    //Asks for an input from the user
    String command = input.nextLine();
    command = command.toUpperCase();
    String commandParts[] = command.split(" ");
    int limit = 1;

    //Assigns an integer value to the command that is entered
    switch(commandParts[0]){
      case "HELLO":
        choice[0] = 1;
        break;
        
      case "GOLD":
        choice[0] = 2;
        break;
        
      case "LOOK":
        choice[0] = 3;
        break;
        
      case "MOVE":
        choice[0] = 4;
        limit = 2;
        
        try{
          
          switch(commandParts[1]){
            case "N":
              choice[1] = 1;
              break;
            case "S":
              choice[1] = 2;
              break;
            case "E":
              choice[1] = 3;
              break;
            case "W":
              choice[1] = 4;
              break;
          }
        }
        //If no direction is given, then choice is set to an invalid choice
        catch (ArrayIndexOutOfBoundsException e){
          choice[0] = 0;
        }
        break;
        
      case "PICKUP":
        choice[0] = 5;
        break;
        
      case "QUIT":
        choice[0] = 6;
        break;
    }
    
    //Checks whether the command is valid (no excess words)
    try{
      String invalid = commandParts[limit];
      choice[0] = 0;
    }
      
    catch (ArrayIndexOutOfBoundsException e){
      //Means it is correct
    }
    return choice;
  }
    
  
  //Updates the data of the player to a data of another player data type
  //@params : A player data type
  public void UpdateObject(Player current){
    location = current.getLocation();
    goldCollected = current.getGoldCollected();
    icon = current.getIcon();
    onGold = current.getOnGold();
    onExit = current.getOnExit();
  }

  
  //The following methods are mutators
  public void UpdateLocation(int[] newLocation){
    this.location = newLocation;
  }

  
  public void UpdateOnGold(boolean newOnGold){
    this.onGold = newOnGold;
  }

  
  public void UpdateOnExit(boolean newOnExit){
    this.onExit = newOnExit;
  }

  
  public void UpdateGoldCollected(int newGoldCollected){
    this.goldCollected = newGoldCollected;
  }

  //The following methods are accessors
  public int[] getLocation(){
    return this.location;
  }

  
  public int getGoldCollected(){
    return this.goldCollected;
  }

  
  public char getIcon(){
    return this.icon;
  }

  
  public boolean getOnGold(){
    return this.onGold;
  }

  
  public boolean getOnExit(){
    return this.onExit;
  }
  

}