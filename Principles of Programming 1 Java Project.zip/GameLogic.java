import java.util.Arrays;


//This is a class that controls the logic of the game and completes most of the game's processes
public class GameLogic {
	
	//This is the map that is used for the game
	private Map map;

  //This is the bot that acts as the villian of the game
  private BotPlayer bot;

  //This is the player that acts as the hero of the game that is controlled by the user
  private HumanPlayer player;

  //This is the player who's turn it currently is (it is a HumanPlayer as BotPlayer inherts from it and hence can be represented by it)
  private HumanPlayer current;

  //This shows whether it is the bot's turn or not
  private boolean botTurn;

  
	//The constructor that is used for the default map
	public GameLogic() {
		map = new Map();
    player = new HumanPlayer(map);
    bot = new BotPlayer(map);
    current = new HumanPlayer(map);
    //Removes the icon that the current has set in its location
    map.changeMap(current.getLocation(), '.');
    botTurn = true;
	}

  
  //The constructor that is used for a specific map
  //@params : the name of the map's file
  public GameLogic(String fileName) {
		map = new Map(fileName);
    player = new HumanPlayer(map);
    bot = new BotPlayer(map);
    current = new HumanPlayer(map);
    map.changeMap(current.getLocation(), '.');
    botTurn = true;
	}

  
  //This is the whole turn system
  //@returns : whether the game is still running or not (true or false)
  public boolean gameRunning() {
    int[] choice;
    
    //Checks if the location of the player and the bot are the same and if so, the game ends
    if (Arrays.equals(bot.getLocation(), player.getLocation())){
      System.out.println("LOSE");
      return false;
    }

    //If the previous turn was the bot's then the current turn is the players
    if (botTurn == true){
      botTurn = false;

      //Obtains the player's choice of action for the turn
      choice = player.Turn();

      //Updates the current player's data to the user's data
      current.UpdateObject(player);
    }

    //Otherwise, it is the bot's turn
    else{
      botTurn = true;
      
      //Obtains the player's choice of action for the turn
      choice = bot.Turn();
      
      //Updates the current player's data to the bot's data
      current.UpdateObject(bot);
    }

    //
    switch(choice[0]){

      //If the action is HELLO
      case 1:
        
        //Gold to win is only printed if its user's turn
        if (botTurn == false){
          System.out.println("Gold to win: "+Hello());
        }
          
        //Otherwise, the gold required is updated for the bot
        else{
          bot.UpdateGoldRequired(Hello());
        }
        break;

      //If the action is GOLD
      case 2:
        //As only the player calls this, the amount of gold they have is printed
        System.out.println("Gold owned: "+Gold());
        break;

      //If the action is LOOK
      case 3:
        //Obtains the 5x5 array of the player's view
        char[][] array = Look();

        //If it is the user's turn then it prints out the view to them
        if (botTurn == false){
          char item;
          
          for (int i = 0; i<5; i++){
            
            for (int j = 0; j<5;j++){
              item = array[i][j];
              System.out.print(item);
            }
            System.out.println();
          }
        }

        //Otherwise, the bot interprets the array
        else{
          bot.InterpretMap(array);
        }
        break;

      //If the action is MOVE X
      case 4:
        Move(choice[1]);
        break;

      //If the action is PICKUP
      case 5:
        boolean success = Pick();

        //Only prints messages according to whether the pickup was successful if it is the user's turn
        if (botTurn == false){
          if (success == true){
            System.out.print("Success  ");
          }
          else{
            System.out.print("Fail  ");
          }
        
          System.out.println("Gold owned: "+Gold());
        }
        break;

      //If the action is QUIT
      case 6:
        boolean victory = Quit();

        //Only victory is turn and it is the player's turn, 'WIN' is printed
        if (victory == true && botTurn == false){
          System.out.println("WIN");
        }

        //Otherwise, 'LOSE' is printed.
        else{
          System.out.println("LOSE");
        }
        return false;

      //If an invalid action is selected, 'Fail' is printed
      default:
        System.out.println("Fail");
    }
    
    //If it is the bot's turn, then the bot's data is updated to the current player's data
    if (botTurn == true){
      bot.UpdateObject(current);
    }

    //Otherwise, the player's (user's) data is updated to the current player's data
    else{
      player.UpdateObject(current);
    }
    return true;
  }

  //This is used if the player wanted to perform HELLO
  //@returns : the gold required to win
  public int Hello() {
    return map.getGoldRequired();
  }

  //This is used if the player wanted to perform GOLD
  //@returns : the gold that the player has
  public int Gold(){
    return current.getGoldCollected();
  }

  //This is used if the player wanted to perform LOOK
  //@returns : the 5x5 array of the user's view
  public char[][] Look(){
    
    int[] location = current.getLocation();
    char[][] lookmap;
    char[][] full_map = map.getMap();
    int[] length = map.getLength();

    //A 5x5 2d array is initalised
    lookmap = new char[5][5];
    
    //The starting y position is set (in connection with map location)
    int first_y = location[0]-2;

    for (int y = 0;y<5;y++){

      //The starting x position is set (in connection with map location)
      int first_x = location[1]-2;
      
      for (int x = 0; x<5;x++){

        //If the y is less than 0 or greater than the number of rows in the map then '#' is added to the 5x5 map
        if (first_y < 0 || first_y>=length[0]){
          lookmap[y][x] = '#';
        }

        //If the x is less than 0 or greater than the number of rows in the map then '#' is added to the 5x5 map 
        else if(first_x<0 || first_x>=length[1]){
            lookmap[y][x] = '#';
        }

        //Otherwise, it adds value in that location on the map to the 5x5 map
        else{
          lookmap[y][x] = full_map[first_y][first_x];
        }
        
      //Increments the next x value by 1 (in connection with map location)
      first_x += 1;
      }
      
      //Increments the next y value by 1 (in connection with map location)
      first_y += 1;
    }
    return lookmap;
  }

  
  //This is used if the player wanted to perform MOVE X
  //@params : the direction of the movement
  public void Move(int direction){
    
    //Index that shows the movement on each axis ({y,x}) 
    int index[] = {0,0};
    boolean valid = true;
    
    switch (direction){

      //If the case if 1 (North), then the movement is -1 on the y axis
      case 1:
        index[0] = -1;
        break;

      //If the case if 2 (South), then the movement is 1 on the y axis
      case 2:
        index[0] = 1;
        break;

      //If the case if 3 (East), then the movement is 1 on the x axis
      case 3:
        index[1] = 1;
        break;

      //If the case if 4 (West), then the movement is -1 on the x axis
      case 4:
        index[1] = -1;
        break;
      
      //If it is anything else, then an invalid movement was picked
      default:
        valid = false;
    }

    
    int[] location = current.getLocation();
    char[][] array = map.getMap();

    //The new location of the map is calculated
    int[] newloc = {location[0]+index[0],location[1]+index[1]};

    //The element in the next location
    char next_location = '#';

    //Sees whether the movement is not outside the map (if the map has no walls around it)
    try{
      next_location = array[newloc[0]][newloc[1]];
    }
    
    catch (ArrayIndexOutOfBoundsException e){
      valid = false;
    }

    //Checks if any errors with the input occurred or if the element in the new location is a wall
    if (valid == false ||next_location == '#'){

      //Only prints out 'Fail' if it isn't the bot's turn
      if (botTurn == false){
        System.out.println("Fail");
        
      }
    }

    //If the element location isn't a wall then the movement is successful
    else{

      //Only prints out 'Success' if it isn't the bot's turn
      if (botTurn == false){
        System.out.println("Success");
      }
      
      boolean Gold = current.getOnGold();
      boolean Exit = current.getOnExit();

      //If the player was on Gold, then the current location gets turned back into the gold and onGold gets set to false
      if (Gold == true){
        map.changeMap(location, 'G');
        Gold = false;
      }

      //If the player was on an Exit, then the current location gets turned back into the exit and onExit gets set to false
      else if (Exit == true){
        map.changeMap(location, 'E');
        Exit = false;
      }

      //Otherwise, the current location turns into an empty tile
      else{
        map.changeMap(location, '.');
      }
      //
      map.changeMap(newloc, current.getIcon());

      //If the element of the new location was a gold/exit then the onGold/onExit is updated to true
      if (next_location == 'G'){
        Gold = true;
      }
      if (next_location == 'E'){
        Exit = true;
      }

      //Updates the location, onGold, onExit of the current player
      current.UpdateLocation(newloc);
      current.UpdateOnGold(Gold);
      current.UpdateOnExit(Exit);

      //Allows the bot to interrupt its location if it is its turn
      if (botTurn == true){
        bot.InterpretLocation();
      }
    }
  }

  
  //This is used if the player wanted to perform PICKUP
  //@returns : whether the pickup was successful or not (true or false)
	public boolean Pick(){
    boolean onGold = current.getOnGold();

    //If the player is on gold then it is successful
    if (onGold == true){
      onGold = false;
      int gold = current.getGoldCollected() +1;
      
      //Updates both the gold collected and sets onGold to false
      current.UpdateGoldCollected(gold);
      current.UpdateOnGold(onGold);
      return(true);
    }

    //Otherwise, it isn't successful
    else{
      return(false);
    }
  }

  
  //This is used if the player wanted to perform QUIT
  //@returns : whether a victory was achieved or not (true or false)
  public boolean Quit(){
    boolean victory = false;

    //Only if the player is on the exit and it has the required gold to win does the method return true
    if (current.onExit == true && current.getGoldCollected() == map.getGoldRequired()){
      victory = true;
    }
    return victory;
  }
}