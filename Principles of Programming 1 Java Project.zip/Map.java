import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

//This is a class that contains all information about the map
//as well as has methods of accessing and changing its contents

public class Map {

	//This is the entire map as a 2d array
	private char[][] map;
	
	//This is the name of the map
	private String mapName;
	
	//This is the amount of gold required for the player to win
	private int goldRequired;

  //This is the number of rows and columns in the map
  private int[] length;

  
	//This is the default constructor for the map
	public Map() {
    basicMap();
  }

  
  //This is the data for the default map
  public void basicMap(){
		mapName = "Very small Labyrinth of Doom";
		goldRequired = 2;
		map = new char[][]{
		{'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'},
		{'#','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#'},
		{'#','.','.','.','.','.','.','G','.','.','.','.','.','.','.','.','.','E','.','#'},
		{'#','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#'},
		{'#','.','.','E','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#'},
		{'#','.','.','.','.','.','.','.','.','.','.','.','G','.','.','.','.','.','.','#'},
		{'#','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#'},
		{'#','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','.','#'},
		{'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'}
		};
    length = new int[]{map.length,map[0].length};
	}

  
	//This is the constructor for a specific map
  //@params : Name of the map's file
	public Map(String fileName) {
		readMap(fileName);
    length = new int[] {map.length,map[0].length};
	}


    //This reads the file and adds the data to the object
    //@params : Name of the map's file
    public void readMap(String fileName) {
      //Gets the number of lines in the file
      int lines = getLines(fileName);
      
      try{
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        int counter = 0;
        String line;
        
        //Reads the file until it reaches the end of it (no next line to read)
        while ((line = reader.readLine()) != null){

          //The first line is the name of the map
          if (counter == 0){
            mapName = "";
            String parts[] = line.split(" ");

            //Appends all the lines after 'name' to the map name
            for (int i =1;i<parts.length;i++){
              mapName = mapName + " " + parts[i];
            }
          }

          //The second line is the amount of gold required to win
          else if (counter == 1){
            String parts[] = line.split(" ");
            
            try{
              //Turns the string goldRequired that was in the file into an integer
              goldRequired = Integer.parseInt(parts[1]);
            }
              
            //If the number of gold Required isn't an integer, then it is set to 0
            catch(NumberFormatException e){
              goldRequired = 0;
            }
          }

          //All future lines are rows of the map
          else if (counter >= 2){

            //If it is the first line of the map then the map 2d array is initialised
            if (counter == 2){
              map = new char[lines-2][line.length()];
            }

            //The elements within the line are added to the array as characters (one by one)
            for (int i=0;i<line.length();i++){
              char element = line.charAt(i);
              map[counter-2][i] = element;
            }
          }
          //Increments to keep track of the number of lines
          counter += 1;
        }
        reader.close();
      }

      //If the map that is being accessed isn't found then the default map is used
      catch(IOException e){
        System.out.println("Map not found");
        System.out.println("Default map selected");
        basicMap();
      }
    }

  
  //Map accessor
  //@returns : the entire map
  public char[][] getMap(){
    return this.map;
  }

  
  //Map mutator (changes the character of a specifc location in the map)
  //@params : The location that needs to be changed and the new element of that location
  public void changeMap(int[] loc, char element){
    map[loc[0]][loc[1]] = element;
  }

  
  //Gold required to win accessor
  //@returns : the gold required for the player to win
  public int getGoldRequired(){
    return this.goldRequired;
  }

  
  //Length accessor
  //@returns : number of rows and columns of the map
  public int[] getLength(){
    return this.length;
  }

  //Gets the number of lines within the map file
  //@params : name of the map file
  //@returns : number of lines in the map file
  public int getLines(String fileName){
    int lines = 0;
    
    try{
      BufferedReader reader = new BufferedReader(new FileReader(fileName));

      //Increments the number of lines everytime that there is another line to read
      while (reader.readLine() != null){
        lines += 1;
      }
      reader.close();
    }

    //If wrong file is opened, then the number of lines is get to 0 (to show an empty map)
    catch(IOException e){
      lines = 0;
    }
    
    return lines;
  }
}
