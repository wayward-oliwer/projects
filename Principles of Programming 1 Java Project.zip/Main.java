import java.util.Scanner;

//This is the main class that will start the game as well as ask for the map from the user
class Main {

  //Creates a public Scanner that checks for user input (it is needs in other classes)
  public static final Scanner inputter = new Scanner(System.in);

  //The program that gets executed when Main is ran
  public static void main(String[] args) {
    
    System.out.println("What type of map would you like:");
    System.out.println("1. Default");
    System.out.println("2. Specific");
    System.out.println("---------------------");
    System.out.println("Enter your choice: ");
    boolean valid = false;
    int choice = 0;
    
    while (valid == false){
      //Asks for an input from the user
      String input = inputter.nextLine();
      
      try{
        //Turns the input into an integer
        choice = Integer.parseInt(input);

        //Checks that it is a 1 or a 2
        //If not then it has to be re-entered
        if (choice <0 || choice>2){
          System.out.println("Invalid choice");
          System.out.println("Re-enter your choice: ");
        }

        //Otherwise it is accepted
        else{
          valid = true;
        }
      }
        
      //If the input isn't an integer, the user has to re-enter a choice
      catch(NumberFormatException e){
        System.out.println("Invalid choice");
        System.out.println("Re-enter your choice: ");
      }   
    }
    
    System.out.println("---------------------");
    GameLogic logic;
    
    switch(choice){

      //If the choice is 2, then the file name of the map must be entered
      case 2:
        System.out.println("Enter the file name of the map you want to play: ");
        String mapFileName = inputter.nextLine();
        System.out.println("---------------------");
        
        //The GameLogic constructor with a specific map is called
        logic = new GameLogic(mapFileName);
        break;

      //Otherwise, the GameLogic constructor with the default map is called
      default:
        logic = new GameLogic();
        break;
    }
    
    //Continues to execute gameRunning until the end is reached (it returns false)
    while (logic.gameRunning() == true){
    }
    inputter.close();
  }
}