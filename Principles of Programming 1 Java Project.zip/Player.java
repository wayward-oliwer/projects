//An interface that provides the 'blueprint' methods that all Players must have (both bots and humans)
public interface Player{
  
  //All accessors are defined in HumanPlayer
  int[] getLocation();
  
  int getGoldCollected();
  
  char getIcon();
  
  boolean getOnGold();
  
  boolean getOnExit();
}