import java.util.Random;
import java.util.Arrays;

//This is a class that inherts all the methods and attributes of HumanPlayer
//But overrides some in order to not require user inputs
//As well as being able to respond to data automatically
public class BotPlayer extends HumanPlayer{

  //This is the location of the user player
  private int[] PlayerLocation;

  //This is the gold that it requires to win
  private int GoldRequired;

  //This is the location of a gold
  private int[] GoldLocation;

  //This is the location of an exit
  private int[] ExitLocation;

  //This is an array of the directions that the bot tried to move
  //True meaning it has tried to go there and failed
  //False meaning it was a tried direction
  private boolean[] directionTried;

  //This is the direction that the bot previously moved from
  private int previous_direction;

  
  //The constructor for the bot
  //@params : the map of the game
  public BotPlayer(Map map){
    super(map, 'B');

    //All unknown values are set to -1
    GoldRequired = -1;
    PlayerLocation = new int[]{-1,-1};
    GoldLocation = new int[]{-1,-1};
    ExitLocation = new int[]{-1,-1};

    //The default values for the following variables
    previous_direction = 1;
    directionTried = new boolean[]{false,false,false,false};
  }


  //This is the turn of the bot player
  //@returns : the action of the player as an integer array
  public int[] Turn(){
    int[] choice = new int[] {0,0};

    //If the GoldRequired is unknown then GOLD is the action seleted
    if (GoldRequired == -1){
      choice[0] = 1;
    }

    //If the bot is on Gold then PICKUP is the action selected
    else if (onGold == true){
      choice[0] = 5;

      //GoldLocation is reset to unknown
      GoldLocation[0] = -1;
    }

    //If it is on the Exit and it has enugh gold to win then QUIT is the action selected
    else if(onExit == true && GoldRequired ==goldCollected){
      choice[0] = 6;
    }

    //If the GoldLocation is known and the bot isn't in that location, then it tries to go there (MOVE is the action selected)
    else if (GoldLocation[0] != -1 && !(Arrays.equals(location, GoldLocation))){
      choice[0] = 4;
      choice[1] = CompareLocation(GoldLocation);
    }

    //If the PlayerLocation is known and the bot isn't in that location, then it tries to go there (MOVE is the action selected)
    else if (PlayerLocation[0] != -1 && !(Arrays.equals(location, PlayerLocation))){
      choice[0] = 4;
      choice[1] = CompareLocation(PlayerLocation);
    }

    //If the bot has enough gold to win, then it tries to get to the exit (MOVE is the action selected)
    else if(goldCollected == GoldRequired && ExitLocation[0] != -1){
      choice[0] = 4;
      choice[1] = CompareLocation(ExitLocation);
    }

    //If the bot is in the player's previously known location, it sets it to unknown and looks around (LOOK is the action selected)
    else if (Arrays.equals(location, PlayerLocation)){
      PlayerLocation[0] = -1;
      choice[0] = 3;
    }

    //Otherwise a random number from 1 to 2 is generated
    else{
      Random random = new Random();
      int rand_int = random.nextInt(2)+1;

      //If it's a 1, then LOOK is the action selected
      if (rand_int == 1){
        choice[0] = 3;
      }

      //Otherwise, MOVE is the action selected with a random direction
      else{
        choice[0] = 4;
        choice[1] = RandomLocation();
      }
    }
    return choice;
  }

  
  //This updates the gold required for the bot to win
  //@params : the gold required to win
  public void UpdateGoldRequired(int gold){
    GoldRequired = gold;
  }


  //This resets the directionTried to false after a movement was successful
  public void InterpretLocation(){
    
    for (int i=0;i<4;i++){
      
      if (directionTried[i] == true){
        directionTried[i] = false;
      }
      
      //Sets the previous direction as true so the bot doesn't return to its previous location
      directionTried[previous_direction-1] = true; 
    }
  }

  
  //This interprets the 5x5 map that the bot gets from LOOK
  //@params : the 5x5 view map obtained from LOOK
  public void InterpretMap(char[][] map){

    //Goes through all the elements in the 5x5 LOOK map
    for (int i=0;i<5;i++){
      int coordinate_y = i + (location[0]-2);
      
      for(int j=0;j<5;j++){
        int coordinate_x = j + (location[1]-2);

        //If the element is a player, then the player's location is saved
        if (map[i][j] == 'P'){
          PlayerLocation[0] = coordinate_y;
          PlayerLocation[1] = coordinate_x;
        }

        //If the element is an exit, then the exit's location is saved
        else if (map[i][j] == 'E'){
          ExitLocation[0] = coordinate_y;
          ExitLocation[1] = coordinate_x;
        }

        //If the element is a gold, then the gold's location is saved
        else if (map[i][j] == 'G'){
          GoldLocation[0] = coordinate_y;
          GoldLocation[1] = coordinate_x;
        }

        //Checks with the adjacent tiles on the y axis are walls
        //If so, prevent the bot from attempting those direction 
        //by making that directionTried index true
        if (j == 2){
          if (map[1][j] == '#'){
            directionTried[0] = true;
          }
          
          if (map[3][j] == '#'){
            directionTried[1] = true;
          }
        }
      }

      //Checks with the adjacent tiles on the x axis are walls
      //If so, prevent the bot from attempting those direction 
      //by making that directionTried index true
      if (i == 2){
        if (map[i][1] == '#'){
          directionTried[3] = true;
        }
        
        if (map[i][3] == '#'){
          directionTried[2] = true;
        }
      }
    }
  }

  //This compares the goal location to the bot's current location
  //@params : The goal location as an integer array
  //@returns : The direction of movement as an integer
  public int CompareLocation(int[] itemLocaton){
    int compass = 0;
    int difference;

    //If the y axes are the same, then the difference of the x axes is calculated
    if (itemLocaton[0] == location[0]){
      difference = itemLocaton[1] - location[1];

      //If the difference is negative then go west
      if (difference <0){
        compass = 4; //West
      }

      //Otherwise, go east
      else{
        compass = 3; //East
      }
    }

    //Otherwise, the difference of the y axes is calculated
    else{
      difference = itemLocaton[0] - location[0];

      //If the difference is negative then go north
      if (difference <0){
        compass = 1; //North
      }

      //Otherwise, go south
      else{
        compass = 2; //South
      }
    }
    
    //Checks if all directions were tried
    boolean valid = true;
    for (int i=0;i<4;i++){
      if (directionTried[i] == false){
        valid = false;
        break;
      }
    }

    //If all directions have been attempted, the bot will return to its previous location
    if (valid == true){
      compass = previous_direction;
    }

    //If the chosen direction was attempted, then random direction is selected
    else if (directionTried[compass-1] == true){
      compass = RandomLocation();
    }
    
    previousDirectionSetter(compass);
    return compass;
  }

  
  //This generates a random direction for the bot to go to
  //@returns : the integer of the random direction
  public int RandomLocation(){
    boolean valid = true;
    int dir = 0;
    
    //Checks if all direction have been tried
    for (int i=0;i<4;i++){
      if (directionTried[i] == false){
        valid = false;
        break;
      }
    }
    
    //If so then, the bot returns to its previous direction
    if (valid == true){
      dir = previous_direction;
    }

    //Otherwise, it generates a random number
    else{
      Random random = new Random();
      int random_int = random.nextInt(4)+1;

      //Keeps generating a random number until the direction wasn't attempted
      while (directionTried[random_int-1] == true){
        random_int = random.nextInt(4)+1;
      }
      dir = random_int;
    }
    previousDirectionSetter(dir);
    return dir;
  }

  
  //This sets the previous direction
  //@params : the current direction that the bot is going to
  public void previousDirectionSetter(int compass){
    switch (compass){
        
      case 1: //North
        previous_direction = 2; //South
        break;
        
      case 2: //South
        previous_direction = 1; //North
        break;
        
      case 3: //East
        previous_direction = 4; //West
        break;
        
      case 4: //West
        previous_direction = 3; //East
        break;
    }
    
    directionTried[compass-1] = true;
  }
  
}