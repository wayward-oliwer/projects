class record:
    def __init__(self):
        self.color = ""
        self.newrow = 0
        self.newcolumn = 0
        self.row = 0
        self.column = 0

begining = [[" ", "1","2", "3", "4", "5", "6","7", "8"],
            ["A","BT","BH","Bb","BQ","BK","Bb","BH", "BT"],
            ["B","BP","BP","BP","BP","BP","BP","BP", "BP"],
            ["C"," "," "," "," "," "," "," ", " "],
            ["D"," "," "," "," "," "," "," ", " "],
            ["E"," "," "," "," "," "," "," ", " "],
            ["F"," "," "," "," "," "," "," ", " "],
            ["G","WP","WP","WP","WP","WP","WP","WP", "WP"],
            ["H","WT","WH","Wb","WK","WQ","Wb","WH", "WT"]]

def pawn(position, board):
    double = False
    changy = False
    valid = False
    if position.color == "B":
        pr = position.row + 1
        if position.row == 2:
            double = True
    elif position.color == "W":
        pr = position.row - 1
        if position.row == 7:
            double = True        
    pc = position.column + 1
    nc = position.column - 1
    if position.column == 8:
        if board[pr][pc] != " ":
            if board[position.newrow][position.newcolumn] == board[pr][pc]:
                valid = True
    elif position.column == 1:
        if board[pr][nc] != " ":
            if board[position.newrow][position.newcolumn] == board[pr][nc]:
                valid = True
    else:
        if board[pr][nc] != " ":
            if board[position.newrow][position.newcolumn] == board[pr][nc]:
                valid = True
        if board[pr][pc] != " ":
            if board[position.newrow][position.newcolumn] == board[pr][pc]:
                valid = True
    if double == True:
        valid = True
        if position.color == "B":
            for i in range(1,3):
                if board[position.row+i][position.column] != " ":
                    valid = False
        else:
            for i in range(1,3):
                if board[position.row-i][position.column] != " ":
                    valid = False
    else:
        if position.newrow == pr:
            if position.column == position.newcolumn:
                if board[pr][position.column] == " ":
                    valid = True
    while valid != True:
        print("Your new position isn't possible with the pawn you picked.")#add thing that allows user to change to position they move
        print("New position for the pawn must be entered...")
        newcolumn, newrow = location("move")
        position.newrow = newrow
        position.newcolumn = newcolumn
        pawn(position,board)
    board[position.newrow][position.newcolumn] = position.color + "P"
    board[position.row][position.column] = " "
    if position.color == "W":
        if position.newrow == 1:
            changy = True
    if position.color == "B":
        if position.newrow == 8:
            changy = True
    if changy == True:
        array = ["T", "H", "b", "Q"]
        print("T = Tower")
        print("H = Knight")
        print("b = Bishop")
        print("Q = Queen")
        print("Use the index above to pick the figure")
        print("Enter what figure you want to exchange your pawn for:")
        figure = input()
        while figure not in array:
            print("The figure you entered is invalid")
            print("Re-enter your choice: ")
            figure = input()
        board[position.newrow][position.newcolumn] = position.color + figure

def tower(position,board):
    valid = False
    if position.newrow == position.row:
        valid = True
        for i in range(position.column, position.newcolumn):
            if board[i][position.newcolumn] != " ":
                valid = False
    if position.newcolumn == position.column:
        valid = True
        for i in range(position.row, position.newrow):
            if board[position.newrow][i] != " ":
                valid = False
    if position.color in position[position.newrow][position.newcolumn]:
        valid = False
    while valid != True:
        print("Your new position isn't possible with the tower you picked.") #add thing that allows user to change to position they move
        print("New position for the tower must be entered...")
        newcolumn, newrow = location("move")
        position.newrow = newrow
        position.newcolumn = newcolumn
        tower(position,board)
    board[position.newrow][position.newcolumn] = position.color + "T"
    board[position.row][position.column] = " "
    
def horse(position,board):
    print("no")
def bishop(position,board):
    valid = False
    if position.newrow != position.row:
        valid = True
        for i in range(position.column, position.newcolumn):
            if board[position.row + 1][position.column + 1] != " ":
                valid = False
            if board[position.row - 1][position.column + 1] != " ":
                valid = False
            if board[position.row + 1][position.column - 1] != " ":
                valid = False
            if board[position.row - 1][position.column - 1] != " ":
                valid = False
    if position.newcolumn != position.column:
        valid = True
        for i in range(position.row, position.newrow):
            if board[position.row + 1][position.column + 1] != " ":
                valid = False
            if board[position.row - 1][position.column + 1] != " ":
                valid = False
            if board[position.row + 1][position.column - 1] != " ":
                valid = False
            if board[position.row - 1][position.column - 1] != " ":
                valid = False
        if position.color in position[position.newrow][position.newcolumn]:
            valid = False
    while valid != True:
        print("Your new position isn't possible with the bishop you picked.") #add thing that allows user to change to position they move
        print("New position for the tower must be entered...")
        newcolumn, newrow = location("move")
        position.newrow = newrow
        position.newcolumn = newcolumn
        bishop(position,board)
    board[position.newrow][position.newcolumn] = position.color + "b"
    board[position.row][position.column] = " "
        
def queen(position,board):
    valid = False
    if position.newrow != position.row:
        valid = True
        for i in range(position.column, position.newcolumn):
            if board[position.row + 1][position.column + 1] != " ":
                valid = False
            if board[position.row - 1][position.column + 1] != " ":
                valid = False
            if board[position.row + 1][position.column - 1] != " ":
                valid = False
            if board[position.row - 1][position.column - 1] != " ":
                valid = False
    if position.newcolumn != position.column:
        valid = True
        for i in range(position.row, position.newrow):
            if board[position.row + 1][position.column + 1] != " ":
                valid = False
            if board[position.row - 1][position.column + 1] != " ":
                valid = False
            if board[position.row + 1][position.column - 1] != " ":
                valid = False
            if board[position.row - 1][position.column - 1] != " ":
                valid = False
        if position.color in position[position.newrow][position.newcolumn]:
            valid = False
    if position.newrow != position.row:
        valid = True
        for i in range(position.column, position.newcolumn):
            if board[position.row + 1][position.column + 1] != " ":
                valid = False
            if board[position.row - 1][position.column + 1] != " ":
                valid = False
            if board[position.row + 1][position.column - 1] != " ":
                valid = False
            if board[position.row - 1][position.column - 1] != " ":
                valid = False
    if position.newcolumn != position.column:
        valid = True
        for i in range(position.row, position.newrow):
            if board[position.row + 1][position.column + 1] != " ":
                valid = False
            if board[position.row - 1][position.column + 1] != " ":
                valid = False
            if board[position.row + 1][position.column - 1] != " ":
                valid = False
            if board[position.row - 1][position.column - 1] != " ":
                valid = False
        if position.color in position[position.newrow][position.newcolumn]:
            valid = False
    while valid != True:
        print("Your new position isn't possible with the bishop you picked.") #add thing that allows user to change to position they move
        print("New position for the tower must be entered...")
        newcolumn, newrow = location("move")
        position.newrow = newrow
        position.newcolumn = newcolumn
        bishop(position,board)
    board[position.newrow][position.newcolumn] = position.color + "b"
    board[position.row][position.column] = " "
def king(position,board):
    print("no")
def checkmate(board):
    for i in range(1,9):
        for x in range(1,9):
            if turn.color == "W":
                if begining[i][x] == "BK":
                    king_row = i
                    king_column = x
            else:
                if begining[i][x] == "WK":
                    king_row = i
                    king_column = x
    turn.newrow = king_row
    turn.newcolumn = king_column
    for i in range(1,9):
        for x in range(1,9):
            if turn.color in begining[i][x]:
                turn.row = i
                turn.column = x
                #check whether it can check the King by seeing what piece it is.
                
                

def displayBoard(board):
    print("-----------------------------------------------------------")
    print('\n'.join([''.join(['{:7}'.format(item) for item in row]) for row in board]))
    print("-----------------------------------------------------------")

def location(thing):
    if thing == "choose":
        phrase = "the figure you want to move: "
    elif thing == "move":
        phrase = "the place you want your figure to move to: "
    print("Name the row of", phrase)
    row = input()
    row = row.upper()
    nr = ord(row) - 64
    while nr not in range(1,9):
        print("Invalid row choice..")
        row = input("Re-enter choice: ")
        row = row.upper()
        nr = ord(row) - 64
    print("-----------------------------------------------------------")
    print("Name the column of", phrase)    
    c = int(input())
    while c not in range(1,9):
        print("Invalid column choice..")
        c = int(input("Re-enter choice: "))
    print("-----------------------------------------------------------")
    return c, nr
#--------------------------------------------------------------------------------------------------------------------------
valid = False
i = 0
print("-----------------------------------------------------------")
print("Welcome to Chess!")
print("-----------------------------------------------------------")
print("Key:")
print("B = Black")
print("W = White")
print("T = Tower")
print("H = Knight")
print("b = Bishop")
print("Q = Queen")
print("K = King")
print("P = Pawn")
print("-----------------------------------------------------------")
print("Columns are from 1 to 8")
print("Rows are from A to H")


while valid == False:
    displayBoard(begining)
    if i%2 == 0:
        print("It's White's turn...")
        turn = record()
        turn.color = "W"
    else:
        print("It's Black's turn...")
        turn = record()
        turn.color = "B"

    column, norow = location("choose")
    
    while turn.color not in begining[norow][column]:
        if begining[norow][column] == " ":
            print("There is no figure there.")
            column, norow = location("choose")
        else:
            print("This is not your figure.")
            column, norow = location("choose")

    newcolumn, newrow = location("move")
    turn.newrow = newrow
    turn.newcolumn = newcolumn
    turn.row = norow
    turn.column = column
    if "T" in begining[norow][column]:
        tower(turn, begining)
    elif "H" in begining[norow][column]:
        knight(turn, begining)
    elif "b" in begining[norow][column]:
        bishop(turn, begining)
    elif "Q" in begining[norow][column]:
        queen(turn, begining)
    elif "K" in begining[norow][column]:
        king(turn, begining)
    elif "P" in begining[norow][column]:
        pawn(turn, begining)
    checkmate(begining)
    i = i + 1
